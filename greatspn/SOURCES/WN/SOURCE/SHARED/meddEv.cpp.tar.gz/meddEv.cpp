

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "medd.h"



extern ifstream fin;
extern ofstream fout;
extern int Max_Token_Bound;
extern bool EVMDD;
extern double _prec;
extern int _iter;

namespace dddRS
{

RSRG::RSRG(const int& npl,std::string netname){
  
this->cardinality=0.0;  
this->npl=npl;
this->netname=netname;

//Create DD ComputeManager
cm = MEDDLY_getComputeManager();

//Create DD domain
d = MEDDLY_createDomain();
int* bounds = (int *) malloc((npl) * sizeof(int*));
for (int i=0;i<npl;i++)
  	{
    	bounds[i]=Max_Token_Bound;
  	}
d->createVariablesBottomUp(bounds, npl);

// Create DD forests
fRS = d->createForest(false, forest::BOOLEAN,forest::MULTI_TERMINAL);	
fRS->setNodeStorage(forest::FULL_OR_SPARSE_STORAGE);
fRS->setNodeDeletion(forest::OPTIMISTIC_DELETION);

fTranB =d->createForest(true, forest::BOOLEAN, forest::MULTI_TERMINAL);
fTranB->setNodeStorage(forest::FULL_OR_SPARSE_STORAGE);
fTranB->setNodeDeletion(forest::OPTIMISTIC_DELETION);

fTranR=d->createForest(true, forest::REAL, forest::MULTI_TERMINAL);
fTranR->setNodeStorage(forest::FULL_OR_SPARSE_STORAGE);
fTranR->setNodeDeletion(forest::OPTIMISTIC_DELETION);

//it is initialized only when it needs
fEV=NULL;


//Create DD edge

rs = new dd_edge(fRS);
initMark = new dd_edge(fRS);
indexrs= NULL;
NSFt = new dd_edge(fTranB);
NSFi = new dd_edge(fTranB);
NSFtReal = new dd_edge(fTranR);
DiagReal = new dd_edge(fTranR);
VectNSFtReal = (dd_edge **) malloc((ntr)* sizeof(dd_edge*));
for (int i=0; i<ntr;i++)
	{
	VectNSFtReal[i]= new dd_edge(fTranR);
	}

//Create vector
to= (int **) malloc((1)* sizeof(int*));
to[0]=(int *) malloc((npl+1) * sizeof(int));
from= (int **) malloc((1)* sizeof(int*));
from[0] =(int *) malloc((npl+1) * sizeof(int));
ins=(int **) malloc((1)* sizeof(int*));
ins[0]=(int *) malloc((npl+1) * sizeof(int));

for (int i=0;i<npl+1;i++)
	{
	to[0][i]=from[0][i]=ins[0][i]=-2;
	}


//Create mapping  between Place name and interger
for (int i=0;i<npl;i++)
	{
	S2Ipl[std::string(tabp[i].place_name)]=i;
	}

for (int i=0;i<ntr;i++)
	{
	S2Itr[std::string(tabt[i].trans_name)]=i;
	}

//Free memory
free(bounds);
}


bool RSRG::init_RS(const Net_Mark_p& net_mark){

ins[0][0]=0;
for(int pl = 0 ; pl < npl; pl++)
	{/* foreach place */
        ins[0][pl+1]=net_mark[pl].total;
  	}/* foreach place */
fRS->createEdge(ins, 1, *rs);
fRS->createEdge(ins, 1, *initMark);
#if DEBUG
for (int i=0;i<npl+1;i++)
		{
		cout<<"["<<i<<"]"<<ins[0][i]<<" ";
		}
cout<<endl<<endl;
#endif

#if DEBUG1
  cout<<"\nInitial Marking\n";
  (*rs).show(stdout,true);
#endif
return 0;
}

//Questo metodo va ricontrollato e ottimizzato!!!
void RSRG::MakeNextState(int* f,int* t, int* h,const int& tt,int pl)
{
pl++;
while ((f[pl]==0)&&(t[pl]==0))
	pl++;

if (pl==npl)
	{
	float rate=tabt[tt].mean_t;	
	dd_edge temp(fTranB);
	dd_edge tempReal(fTranR);
	dd_edge tempDiagReal(fTranR);
	
	fTranB->createEdge(from,to, 1, temp);
	fTranR->createEdge(from,to,&rate,1,tempReal);
#if DEBUG
	for(int i=1;i<npl+1;i++)
		{
		cout<<from[0][i]<<" ";
		}
	cout<<endl;
	for(int i=1;i<npl+1;i++)
		{
		cout<<to[0][i]<<" ";
		}
	cout<<endl;
#endif
	rate=rate;
	fTranR->createEdge(from,from,&rate,1,tempDiagReal);
	(*NSFt)+=temp;
	(*NSFtReal)+=tempReal;
	(*DiagReal)+=tempDiagReal;
	//throughput
	(*VectNSFtReal[tt])+=tempDiagReal;
	temp.clear();
	tempReal.clear();
	tempDiagReal.clear();
	rate=1;
	tempReal.clear();
	}
else
	{
	int b=Max_Token_Bound-1;
	if (f[pl]>0)
		{
		while ((b-f[pl]>=0))
			{
			from[0][pl+1]=b;
			to[0][pl+1]=b-f[pl]+t[pl];
			if (to[0][pl+1]<=Max_Token_Bound-1)
				{
				this->MakeNextState(f,t,h,tt,pl);
				}
			b--;
			}
		}
	else
		{
		if (t[pl]>0)
			{
			while ((b>=0)&&(t[pl]>0))
				{
				from[0][pl+1]=b;
				to[0][pl+1]=b+t[pl];
				if (to[0][pl+1]<=Max_Token_Bound-1)
					{
					this->MakeNextState(f,t,h,tt,pl);
					}
				b--;
				}
			}
		else
			{
			this->MakeNextState(f,t,h,tt,pl);
			}
		}
to[0][pl+1]=from[0][pl+1]=-2;
	}
}


bool RSRG::MakeNextState(int* f,int* t, int* h,const int& tt)
{

dd_edge nsf(fTranB);
dd_edge asf(fTranB);
dd_edge nsfReal(fTranR);
dd_edge asfReal(fTranR);

dd_edge temp(fTranB);
dd_edge tempReal(fTranR);
dd_edge tempDiagReal(fTranR);
dd_edge aDiagReal(fTranR);


int aa=0;

float rate=tabt[tt].mean_t;
int prio=tabt[tt].pri;

for (int i=0;i<npl+1;i++)
	{
	if ((i>0)&&(f[i-1]==0)&&(t[i-1]==0)&&(h[i-1]==0))
		to[0][i]=from[0][i]=-2;
	else
		to[0][i]=from[0][i]=-1;
	}

for (int pl=0;pl<npl;pl++)
	{
	int b=Max_Token_Bound-1;
//archi inibitori
	if (h[pl]!=0)
		{
		b=h[pl]-1;
		}
//archi inibitori
 	nsf.clear();
	nsfReal.clear();
	tempDiagReal.clear();
	aa=0;
	while ((b-f[pl]>=0)&&(f[pl]>0))
		{
		from[0][pl+1]=b;
		to[0][pl+1]=b-f[pl]+t[pl];
		if (to[0][pl+1]<=Max_Token_Bound-1)
			{
			fTranB->createEdge(from,to, 1, temp);
			nsf+=temp;
			temp.clear();
			fTranR->createEdge(from,to,&rate,1,tempReal); //rate solo la prima volta
			nsfReal+=tempReal;
			tempReal.clear();
			fTranR->createEdge(from,from,&rate,1,tempReal);
			tempDiagReal+=tempReal;
			tempReal.clear();
			aa=1;
			}
		b--;
		to[0][pl+1]=from[0][pl+1]=-1;
		}		
	if(aa==1)
		{
		if (asf.getNode()!=0)
		{
			asf*=nsf;
			asfReal*=nsfReal;
			aDiagReal*=tempDiagReal;
		}
		else
		{
			asf+=nsf;
			asfReal+=nsfReal;
			aDiagReal+=tempDiagReal;
		}
		nsf.clear();
		nsfReal.clear();
		tempDiagReal.clear();
		rate=1.0;
		}
	aa=0;
//archi inibitori
	if (h[pl]!=0)
		{
		b=h[pl]-1;
		}
	else
		b=Max_Token_Bound-1;
//archi inibitori	
	while ((b>=0)&&(t[pl]>0)&&(f[pl]==0))
		{
		from[0][pl+1]=b;
		to[0][pl+1]=b+t[pl];
		b--;
		if ((to[0][pl+1]<=Max_Token_Bound-1))
			{
			fTranB->createEdge(from,to, 1, temp);
  			nsf += temp;
			temp.clear();
			fTranR->createEdge(from,to,&rate,1, tempReal);
  			nsfReal += tempReal;
			tempReal.clear();
			fTranR->createEdge(from,from,&rate,1,tempReal);
			tempDiagReal+=tempReal;
			tempReal.clear();
			aa=1;
			}
		from[0][pl+1]=to[0][pl+1]=-1;
		}
	if (aa==1)
		{
		if (asf.getNode()!=0)
			{
			asf*=nsf;
			asfReal*=nsfReal;
			aDiagReal*=tempDiagReal;
			}
		else
			{
			asf+=nsf;
			asfReal+=nsfReal;
			aDiagReal+=tempDiagReal;
			}
		rate=1.0;
		}

//archi inibitori
	if (h[pl]!=0)
		{
		b=h[pl]-1;
		}
	else
		b=Max_Token_Bound-1;
//archi inibitori	
	while (((b>=0)&&(t[pl]==0)&&(f[pl]<=0)&&(h[pl]!=0))||((b>=0)&&(t[pl]==0)&&(b-f[pl]<0)&&(h[pl]!=0)))
		{
		to[0][pl+1]=from[0][pl+1]=b;
		b--;
		fTranB->createEdge(from,to, 1, temp);
  		nsf += temp;
		temp.clear();
		fTranR->createEdge(from,to,&rate,1, tempReal);
  		nsfReal += tempReal;
		tempReal.clear();
		fTranR->createEdge(from,from,&rate,1,tempReal);
		tempDiagReal+=tempReal;
		tempReal.clear();
		aa=1;
		from[0][pl+1]=to[0][pl+1]=-1;
		}
	if (aa==1)
		{
		if (asf.getNode()!=0)
			{
			asf*=nsf;
			asfReal*=nsfReal;
			aDiagReal*=tempDiagReal;
			}
		else
			{
			asf+=nsf;
			asfReal+=nsfReal;
			aDiagReal+=tempDiagReal;
			}
		rate=1.0;
		}	
	} 

if (prio!=0)
	{
	(*NSFi)+=asf;
	}
else
	{
	(*NSFt)+=asf;
	(*NSFtReal)+=asfReal;
	(*DiagReal)+=aDiagReal;
	(*VectNSFtReal[tt])+=aDiagReal;
	}
asf.clear();
asfReal.clear();
aDiagReal.clear();
#if DEBUG
	cout<<"size :"<<(*DiagReal).getCardinality()<<endl;
#endif
return 0;
}



bool RSRG::genRSTimed(){
//Here we assume to work with SPN (without immediate transition)
//un_marking encodes only the initial marking.
if (cm->apply(compute_manager::REACHABLE_STATES_DFS,*rs, *NSFt, *rs)!=0)
	{
	cerr<<"Error REACHABLE_STATES_BFS "<<endl;
	return -1;
	}
return 0;
}



bool RSRG::genRSAll(){

double first,second;

dd_edge reached(fRS);
dd_edge sourceXT(fRS);
dd_edge source(fRS);
dd_edge tmp(fRS);



sourceXT+=*rs;
do
	{
	if (cm->apply(compute_manager::POST_IMAGE,sourceXT, *NSFt, reached)!=0)
		{
		cerr<<"Error  POST_IMAGE"<<endl;
		return -1;
		}	
	sourceXT.clear();
	sourceXT+=reached;
	second=rs->getCardinality();
	(*rs)+=reached;
	do
		{
		if (cm->apply(compute_manager::POST_IMAGE,reached, *NSFi,tmp)!=0)
			{
			cerr<<"Error POST_IMAGE "<<endl;
			return -1;
			}
		first=rs->getCardinality();
		sourceXT+=tmp-(*rs);
		(*rs)+=tmp;
		if (cm->apply(compute_manager::PRE_IMAGE,tmp, *NSFi,source)!=0)
			{
			cerr<<"Error PRE_IMAGE"<<endl;
			return -1;
			}
		sourceXT-=source;
		source.clear();
		reached.clear();
		reached+=tmp;
		tmp.clear();
		}
	while ((rs->getCardinality()-first)>_DIFFMIN(double));
	reached.clear();
	}
while((rs->getCardinality()-second)>_DIFFMIN(double));
return 0;
}



bool RSRG::IndexRS(){
fEV= d->createForest(false, forest::INTEGER, forest::EVPLUS);
indexrs=new dd_edge(fEV);
if (cm->apply(compute_manager::CONVERT_TO_INDEX_SET, *rs, *indexrs)!=0)
	{
	cerr<<"Error  CONVERT_TO_INDEX_SET"<<endl;
	return -1;
	}
return 0;
}


bool RSRG::JacobiSolver(){

int jj=0;



#if DEBUG
for (int i=0;i<npl+1;i++)
		{
		cout<<"["<<i<<"]"<<v[0][i]<<" ";
		}
cout<<endl<<endl;
#endif

double cardinality = this->getSizeRS();
if (cardinality<1)
	{
	return 0;
	}

double* q1 =(double *) malloc((int)cardinality * sizeof(double));
double* q2 =(double *) malloc((int)cardinality * sizeof(double));
double* qold =(double *) malloc((int)cardinality * sizeof(double));
double* h =(double *) malloc((int)cardinality * sizeof(double));
for (jj=0;jj<(int)cardinality;jj++)
	{
	q1[jj]=1/cardinality;

	q2[jj]=0.0;
	qold[jj]=1.0;
	h[jj]=0.0;
	}



if (cm->vectorMatrixMultiply(h, *indexrs,  qold, *indexrs,*DiagReal)!=0)
	{
	cerr<<"Error  generation diagonal"<<endl;
	return -1;
	}
	

int ss=0;
double sum=0.0,diff=0.0,norm=0.0;
bool precision=false;
while ((ss<_iter)&&(!precision))
	{

	if (cm->vectorMatrixMultiply(q2, *indexrs,  q1, *indexrs,*NSFtReal)!=0)
		{
		cerr<<"Error  vectorMatrixMultiply"<<endl;
		exit(0);
		}

	if (ss%1000==0)
		cout<<"\tIteration: "<<ss<<" error: "<<diff<<"\n";
#if DEBUG
	cout<<"Iteration: "<<ss<<" error: "<<diff<<"\n\t";
#endif
sum=diff=norm=0.0;
	for (int jj=0;jj<(int)cardinality;jj++)
		{
		q2[jj]=(q2[jj])/h[jj]+q1[jj];
		sum+=q2[jj];
		}
	for (int jj=0;jj<(int)cardinality;jj++)
		{
		q1[jj]=q2[jj]/sum;
		diff+=pow(q1[jj],2)-pow(qold[jj],2);
		norm+=pow(qold[jj],2);
		qold[jj]=q1[jj];
		q2[jj]=0.0;
		}
	
	diff=(sqrt(fabs(diff)))/sqrt(norm);
	if (diff<_prec)
		precision=true;
#if DEBUG1
	cout<<"error: "<<diff<<endl;
#endif
	ss++;
}
if (diff>_prec)
	{
	cerr<<"\nError: Precision  was not reached!!!"<<endl;
	return -1;
	}
else
	{
#if DEBUG1
	for (int jj=0;jj<(int)cardinality;jj++)
		{
		cout<<q1[jj]<<" ";
		}
	cout<<endl;
#endif
	std::string file=netname+std::string(".prob");
	ofstream out(file.c_str(),ofstream::out);
	if(!out) 
		{
		cerr << "\n*****Error opening output stream .prob *****" << endl;
		return -1;
		}
	out<<setprecision (IOPRECISION);
	for (int jj=0;jj<(int)cardinality;jj++)
		{
		out<<q1[jj]<<endl;
		}
	out.close();
	file=netname+std::string(".sta");
	out.open(file.c_str(),ofstream::out);
	if(!out) 
		{
		cerr << "\n*****Error opening output stream .sta *****" << endl;
		return -1;
		}
	out<<setprecision (IOPRECISION);
	for (int tt=0;tt<ntr;tt++)
		{
		if (cm->vectorMatrixMultiply(q2, *indexrs,  q1, *indexrs,*(VectNSFtReal[tt]))!=0)
			{
			cerr<<"Error  vectorMatrixMultiply"<<endl;
			return -1;
			}
		
		sum=0.0;
		for (int jj=0;jj<(int)cardinality;jj++)
			{
			sum+=q2[jj];
			q2[jj]=0.0;
			}
		out<<"Thru_"<<tabt[tt].trans_name<<" = "<<sum<<endl;
		}
	out.close();
	}
//end implementazione esplicita

//free memory
free(q1);
free(q2);
free(qold);
free(h);

return 0;
}

}



